Crud-Cidade
Criamos uma aplicação para uso pessoal que consegue armazenar dados com as funcionalidades do GET, PUT, POST e DELETE.

Rodando localmente
Clone o projeto

  git clone
Entre no diretório do projeto

  cd crud-cidade
Instale as dependências

  npm  install ou yarn install
npm run mock
Iniciar o servidor

apêndice
Como Ferramente utilizados:

IU de materiais; unform reactjs/typescript; react-axios e uso dos hooks

Autores
@rodrigues28ju
@raquelmachadosantos18
@MarianaHerbst
@IngridCassia
@Maria Fernanda


![WhatsApp Image 2023-01-11 at 10 11 46](https://user-images.githubusercontent.com/114073501/211823485-2523bcb8-4f8c-4bc8-995d-e63f18864aad.jpeg)
